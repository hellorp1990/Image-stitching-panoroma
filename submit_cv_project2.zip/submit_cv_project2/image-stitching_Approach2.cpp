#define _USE_MATH_DEFINES
#include <cmath>
#include <dirent.h>
#include <errno.h>
#include <cassert>

#include "feature/extrema.hh"
#include "feature/matcher.hh"
#include "feature/orientation.hh"
#include "lib/mat.h"
#include "lib/config.hh"
#include "lib/geometry.hh"
#include "lib/imgproc.hh"
#include "lib/planedrawer.hh"
#include "lib/polygon.hh"
#include "stitch/cylstitcher.hh"
#include "stitch/match_info.hh"
#include "stitch/stitcher.hh"
#include "stitch/transform_estimate.hh"
#include "stitch/warp.hh"


using namespace std;
using namespace pano;
using namespace config;

bool TEMPDEBUG = false;

const int LABEL_LEN = 7;

int get_files_in_dir(char * dir, vector<char *> &files)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp  = opendir(dir)) == NULL) {
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }

    while ((dirp = readdir(dp)) != NULL) {
    	if(!(string(dirp->d_name) == "." || string(dirp->d_name) == ".."))
	{
		string fileName = string(dir) + string("/") + string(dirp->d_name);
		char *cstr = new char[fileName.length() + 1];
		strcpy(cstr, fileName.c_str());
    		files.push_back(cstr);
    	}
    }

    closedir(dp);
    return 0;
}

void imageStitch(char * dir) {

	vector<char *> files;
	get_files_in_dir (dir, files);
	int file_count = files.size();
	vector<Mat32f> imgs;

	REPL(i, 1, file_count)
		imgs.emplace_back(read_img(files[i]));
	Mat32f res;
	if (CYLINDER) {
		CylinderStitcher p(move(imgs));
		res = p.build();
	} else {
		Stitcher p(move(imgs));
		res = p.build();
	}
	

	if (CROP) {
		int oldw = res.width(), oldh = res.height();
		res = crop(res);
		print_debug("Crop from %dx%d to %dx%d\n", oldh, oldw, res.height(), res.width());
	}
	{
		
		write_rgb("out.jpg", res);
	}
}

void init_config() {
	const char* config_file = "config.cfg";
	ConfigParser Config(config_file);
	CYLINDER = Config.get("CYLINDER");
	TRANS = Config.get("TRANS");
	ESTIMATE_CAMERA = Config.get("ESTIMATE_CAMERA");
	if (int(CYLINDER) + int(TRANS) + int(ESTIMATE_CAMERA) >= 2)
		error_exit("You set two many modes...\n");
	if (CYLINDER)
		print_debug("Run with cylinder mode.\n");
	else if (TRANS)
		print_debug("Run with translation mode.\n");
	else if (ESTIMATE_CAMERA)
		print_debug("Run with camera estimation mode.\n");
	else
		print_debug("Run with naive mode.\n");

	LINEAR_INPUT = Config.get("LINEAR_INPUT");
	if (!LINEAR_INPUT && !ESTIMATE_CAMERA)
		error_exit("Require LINEAR_INPUT under this mode!\n");
	CROP = Config.get("CROP");
	STRAIGHTEN = Config.get("STRAIGHTEN");
	FOCAL_LENGTH = Config.get("FOCAL_LENGTH");
	MAX_OUTPUT_SIZE = Config.get("MAX_OUTPUT_SIZE");

	SIFT_WORKING_SIZE = Config.get("SIFT_WORKING_SIZE");
	NUM_OCTAVE = Config.get("NUM_OCTAVE");
	NUM_SCALE = Config.get("NUM_SCALE");
	SCALE_FACTOR = Config.get("SCALE_FACTOR");
	GAUSS_SIGMA = Config.get("GAUSS_SIGMA");
	GAUSS_WINDOW_FACTOR = Config.get("GAUSS_WINDOW_FACTOR");
	JUDGE_EXTREMA_DIFF_THRES = Config.get("JUDGE_EXTREMA_DIFF_THRES");
	CONTRAST_THRES = Config.get("CONTRAST_THRES");
	PRE_COLOR_THRES = Config.get("PRE_COLOR_THRES");
	EDGE_RATIO = Config.get("EDGE_RATIO");
	CALC_OFFSET_DEPTH = Config.get("CALC_OFFSET_DEPTH");
	OFFSET_THRES = Config.get("OFFSET_THRES");
	ORI_RADIUS = Config.get("ORI_RADIUS");
	ORI_HIST_SMOOTH_COUNT = Config.get("ORI_HIST_SMOOTH_COUNT");
	DESC_HIST_SCALE_FACTOR = Config.get("DESC_HIST_SCALE_FACTOR");
	DESC_INT_FACTOR = Config.get("DESC_INT_FACTOR");
	MATCH_REJECT_NEXT_RATIO = Config.get("MATCH_REJECT_NEXT_RATIO");
	RANSAC_ITERATIONS = Config.get("RANSAC_ITERATIONS");
	RANSAC_INLIER_THRES = Config.get("RANSAC_INLIER_THRES");
	INLIER_MINIMUM_RATIO = Config.get("INLIER_MINIMUM_RATIO");
	SLOPE_PLAIN = Config.get("SLOPE_PLAIN");

	LM_LAMBDA = Config.get("LM_LAMBDA");
	MULTIPASS_BA = Config.get("MULTIPASS_BA");
}

int main(int argc, char* argv[]) {
	if (argc <= 1)
		error_exit("Need folder for images to stitch.\n");
	
	init_config();
	char * dir = argv[1];
	
	imageStitch(dir);
}
