#include <stdio.h>
#include <iostream>
 #include <errno.h>
#include <dirent.h>
#include "opencv2/core/core.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/nonfree/nonfree.hpp"
#include "opencv2/calib3d/calib3d.hpp"
#include "opencv2/imgproc/imgproc.hpp"
 
using namespace cv;
 
using namespace std;
 
int get_files_in_dir (string dir, vector<string> &files)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp  = opendir(dir.c_str())) == NULL) {
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }

	while ((dirp = readdir(dp)) != NULL) {
		if (!(string(dirp->d_name) == "." || string(dirp->d_name) == ".."))
		{

			files.push_back(dir + "/" + string(dirp->d_name));
		}
	}

    closedir(dp);
    return 0;
}

/** @function main */
int main(int argc, char** argv)
{
	cv::Mat cropped;
	vector<string> files;
	vector<Mat> images;
	get_files_in_dir(argv[1], files);
	int number = files.size();

	for (int i = 0; i < number; i++)
	{
		images.push_back(imread(files[i]));
	}

	int j = 0;
	int l = number;
	while (j < l - 1)
	{
		vector<int> first;
		vector<int> second;
		vector<double> determinant;

		for (int a = 0; a < number; a++)
		{
			for (int k = a + 1; k < number; k++)
			{

				Mat img1, img2;
				Mat gray_image1, gray_image2;
				images[a].copyTo(img1);
				images[k].copyTo(img2);

				cvtColor(img1, gray_image1, CV_RGB2GRAY);
				cvtColor(img2, gray_image2, CV_RGB2GRAY);


				int minHessian = 400;

				SurfFeatureDetector detector(minHessian);
				//SiftFeatureDetector detector(minHessian);

				std::vector< KeyPoint > keypoints_object, keypoints_scene;

				detector.detect(gray_image1, keypoints_object);
				detector.detect(gray_image2, keypoints_scene);

				//-- Step 2: Calculate descriptors (feature vectors)
				SurfDescriptorExtractor extractor;
				//SiftDescriptorExtractor extractor;


				Mat descriptors_object, descriptors_scene;

				extractor.compute(gray_image1, keypoints_object, descriptors_object);
				extractor.compute(gray_image2, keypoints_scene, descriptors_scene);

				//-- Step 3: Matching descriptor vectors using FLANN/BF matcher
				FlannBasedMatcher matcher;
				//BFMatcher matcher(NORM_L2);
				std::vector< DMatch > matches;
				matcher.match(descriptors_object, descriptors_scene, matches);

				double max_dist = 0; double min_dist = 100;

				//-- Quick calculation of max and min distances between keypoints
				for (int i = 0; i < descriptors_object.rows; i++)
				{
					double dist = matches[i].distance;
					if (dist < min_dist) min_dist = dist;
					if (dist > max_dist) max_dist = dist;
				}


				//-- Use only "good" matches (i.e. whose distance is less than 3*min_dist )
				std::vector< DMatch > good_matches;

				for (int i = 0; i < descriptors_object.rows; i++)
				{
					if (matches[i].distance < 3 * min_dist)
					{
						good_matches.push_back(matches[i]);
					}
				}



				std::vector< Point2f > obj;
				std::vector< Point2f > scene;

				for (int i = 0; i < good_matches.size(); i++)
				{
					//-- Get the keypoints from the good matches
					obj.push_back(keypoints_object[good_matches[i].queryIdx].pt);
					scene.push_back(keypoints_scene[good_matches[i].trainIdx].pt);
				}


				// Find the Homography Matrix
				if (obj.size() >= 4)
				{
					double deter;
					Mat H = findHomography(obj, scene, CV_RANSAC);
					deter = cv::determinant(H);
					first.push_back(a);
					second.push_back(k);
					determinant.push_back(deter);

					Mat H1 = findHomography(scene, obj, CV_RANSAC);
					double deter1;
					deter1 = cv::determinant(H1);
					first.push_back(k);
					second.push_back(a);
					determinant.push_back(deter1);

					
				}
				img1.release();
				img2.release();
			}
		}

		
		int f, s, z = 0;
		double x;
		x = 100.0;
		for (int i = 0; i < first.size(); i++)
		{
			if (x > determinant[i] && determinant[i] >= 0.05) {
				x = determinant[i];
				z = i;
			}
		}

		f = first[z];
		s = second[z];


		Mat img1, img2;
		Mat gray_image1, gray_image2;
		images[f].copyTo(img1);
		images[s].copyTo(img2);
		cvtColor(img1, gray_image1, CV_RGB2GRAY);
		cvtColor(img2, gray_image2, CV_RGB2GRAY);

		int minHessian = 400;

		SurfFeatureDetector detector(minHessian);
		//SiftFeatureDetector detector(minHessian);

		std::vector< KeyPoint > keypoints_object, keypoints_scene;

		detector.detect(gray_image1, keypoints_object);
		detector.detect(gray_image2, keypoints_scene);

		//-- Step 2: Calculate descriptors (feature vectors)
		SurfDescriptorExtractor extractor;
		//SiftDescriptorExtractor extractor;


		Mat descriptors_object, descriptors_scene;

		extractor.compute(gray_image1, keypoints_object, descriptors_object);
		extractor.compute(gray_image2, keypoints_scene, descriptors_scene);

		//-- Step 3: Matching descriptor vectors using FLANN/BF matcher
		FlannBasedMatcher matcher;
		
		std::vector< DMatch > matches;
		matcher.match(descriptors_object, descriptors_scene, matches);

		double max_dist = 0; double min_dist = 100;

		//-- Quick calculation of max and min distances between keypoints
		for (int i = 0; i < descriptors_object.rows; i++)
		{
			double dist = matches[i].distance;
			if (dist < min_dist) min_dist = dist;
			if (dist > max_dist) max_dist = dist;
		}

		

		//-- Use only "good" matches (i.e. whose distance is less than 3*min_dist )
		std::vector< DMatch > good_matches;

		for (int i = 0; i < descriptors_object.rows; i++)
		{
			if (matches[i].distance < 3 * min_dist)
			{
				good_matches.push_back(matches[i]);
			}
		}



		std::vector< Point2f > obj;
		std::vector< Point2f > scene;

		for (int i = 0; i < good_matches.size(); i++)
		{
			//-- Get the keypoints from the good matches
			obj.push_back(keypoints_object[good_matches[i].queryIdx].pt);
			scene.push_back(keypoints_scene[good_matches[i].trainIdx].pt);
		}


		// Find the Homography Matrix

		double deter;
		Mat H = findHomography(obj, scene, CV_RANSAC);
		deter = cv::determinant(H);

		std::vector<Point2f> obj_corners(4);
		obj_corners[0] = cvPoint(0, 0); obj_corners[1] = cvPoint(gray_image1.cols, 0);
		obj_corners[2] = cvPoint(gray_image1.cols, gray_image1.rows); obj_corners[3] = cvPoint(0, gray_image1.rows);
		std::vector<Point2f> scene_corners(4);

		perspectiveTransform(obj_corners, scene_corners, H);

		cv::Mat result;
		warpPerspective(img1, result, H, cv::Size(img1.cols + img2.cols, img1.rows + img2.rows));
		cv::Mat half(result, cv::Rect(0, 0, img2.cols, img2.rows));
		img2.copyTo(half);

		Mat g, alpha;
		vector<vector<Point> > contours;
		vector<Vec4i> hierarchy;

		cvtColor(result, g, COLOR_BGR2GRAY);
		threshold(g, alpha, 1, 255, THRESH_BINARY);

		
		findContours(alpha, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
		vector<Point> cnt = contours[0];

		Rect bounding_rect = boundingRect(cnt);
		//rectangle(result, bounding_rect, Scalar(0, 255, 0), 2, 8, 0);
		// Crop the full image to that image contained by the rectangle myROI
		// Note that this doesn't copy the data
		cv::Mat croppedRef(result, bounding_rect);

		// Copy the data into new matrix
		croppedRef.copyTo(cropped);


		if (f<s) 
		{
			images.erase(images.begin() + f);
			images.erase(images.begin() + s - 1);
		}
		else if (f>s) 
		{
			images.erase(images.begin() + s);
			images.erase(images.begin() + f - 1);

		}
		images.push_back(cropped);
		j++;
		number = images.size();
		first.clear();
		second.clear();
		determinant.clear();
		imwrite("Result.jpg", cropped);
	}

	return 0;
}
 

