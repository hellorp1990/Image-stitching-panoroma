image-stitching.cpp

1> To run the code in the circe, provide the following command

alias opcv='module add apps/ffmpeg/2.8.5; module load apps/opencv/2.4.9'
alias gco='g++ -g3 -g -o image-stitching -I/apps/opencv/2.4.9/include -L/apps/opencv/2.4.9/lib -lopencv_core -lopencv_flann -lopencv_imgproc -lopencv_highgui -lopencv_ml -lopencv_video -lopencv_objdetect -lopencv_photo -lopencv_nonfree -lopencv_features2d -lopencv_calib3d -lopencv_legacy -lopencv_contrib -lopencv_stitching -lopencv_videostab'

2> type opcv

3> type gco image-stitching.cpp for compiling

4> ./image-stitching <folder path>